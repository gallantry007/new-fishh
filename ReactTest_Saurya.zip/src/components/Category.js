import React from 'react';

const Category = () => {
  return (
    <div className="Category" id="Category">
      <div className="welcome">
        <h1>Categories</h1>
      </div>
      <div className="grid">
        <div className="project1 projects--medium">
          <div className="menu-card">
            <h1>Fish</h1>
       
          </div>
        </div>
        <div className="project2 projects--medium">
          <div className="menu-card">
            
            <h1>Crustaceans</h1>
        
          </div>
        </div>
        <div className="project3 projects--medium">
          <div className="menu-card">
            <h1>Exotic</h1>
        
          </div>
        </div>
        <div className="project4 projects--medium">
          <div className="menu-card">
            <h1>Spices</h1>
            <div className="menu-name">
            
            </div>
          </div>
        </div>
       
       
       
      </div>
    </div>
  );
}

export default Category;
