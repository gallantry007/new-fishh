import React from 'react';
import '../App.css'

const Hero = () => {
  return (
      <div className="overlay" id="home">
        <section className="intro"> 
          <div className="content">
         
            
          </div>
        </section>
      </div>  
  );
}

export default Hero;
