import React from 'react';

const Login = () => {
  return (
    <div className="login-page" id="login">
      <div className="login-form">
        <div className="Login">

        </div>
    

   <div className="Login">
     <h1>Login</h1>
     <h1>User </h1>
     

    
     <input type='input' ></input>
     <br/>
     <br/>
     <input type='input' ></input>
     <br/>
     <br/>

     <button type="button" class="btn btn-primary">Login </button>
     <br/>
     <br/>
     <br/>
     <h1>forget Password</h1>



   </div>
      </div>
    </div>
  );
}

export default Login;
